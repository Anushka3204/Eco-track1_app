# EcoTrack-Your Personal Carbon Footprint Calculator
GDSC UN GOAL:13 [CLIMATE ACTION] 
How to Run:Open index.html and run on live server!
